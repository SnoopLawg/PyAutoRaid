import os

os.system("taskkill /f /im Main.exe")