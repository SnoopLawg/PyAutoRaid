import pyautogui
import keyboard
import sys

while True:
    pos=pyautogui.position()
    print(pos)
    if keyboard.is_pressed('esc') or keyboard.is_pressed('q'):
        break
    